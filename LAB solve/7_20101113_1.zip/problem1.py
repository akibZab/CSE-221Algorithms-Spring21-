def ispalindrome(word):
    n=len(word)
    if n==0:
        return 'not palindrome'
    for i in range(0,n//2):
        if word[i]!=word[n-i-1]:
            return 'not palindrome'
    return 'palindrome'

pal=0
npal=0
odd=0
eve=0
npar=0
x=open('input_1.txt')
y=x.read()
out=y.split()
print(out)
with open("output_1.txt",'w') as put:
    for i in range(1,len(out),2):
        store=ispalindrome(out[i])
        t = out[i - 1]
        if store=='palindrome':
            pal+=1
            if '.' in t:
                npar+=1
                put.write(out[i - 1] + ' cantnot have a parity and ' + out[i] + ' is a palindrome\n')
            elif int(out[i-1])%2==0:
                eve+=1
                put.write(out[i-1]+ ' has a even parity and '+out[i]+' is a palindrome\n')
            else:
                odd+=1
                put.write(out[i - 1] + ' has a odd parity and ' + out[i] + ' is a palindrome\n')
        else:
            npal+=1
            if '.' in t:
                npar+=1
                put.write(out[i - 1] + ' cannot have a parity and ' + out[i] + ' is not a palindrome\n')
            elif int(out[i - 1]) % 2 == 0:
                eve+=1
                put.write(out[i - 1] + ' has a even parity and ' + out[i] + ' is not a palindrome\n')
            else:
                odd+=1
                put.write(out[i - 1] + ' has a odd parity and ' + out[i] + ' is not a palindrome\n')
with open("record.txt",'w') as put1:
    put1.write('Percentage of odd parity: '+str((100//(len(out)//2))*odd)+'%\n')
    put1.write('Percentage of even parity: ' + str((100 // (len(out) // 2)) * eve)+'%\n')
    put1.write('Percentage of no parity: ' + str((100 // (len(out) // 2)) * npar)+'%\n')
    put1.write('Percentage of palindrome: ' + str((100 // (len(out) // 2)) * pal)+'%\n')
    put1.write('Percentage of non-palindrome: ' + str((100 // (len(out) // 2)) * npal)+'%\n')
