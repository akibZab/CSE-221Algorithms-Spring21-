def Multiply_matrix(A,B):
    c=[[0]*len(B) for i in range(len(B))]
    for i in range(0,len(B)):
        for j in range(0,len(B)):
            for k in range(0,len(B)):
                c[i][j]+=int(A[i][k])*int(B[k][j])
    return c


f=open('input_4.txt','r')
A,B=[],[]
t=f.read()
u=t.split()
for i in range(0,len(u)):
    if i<(len(u)//2):
        A.append(u[i].split(','))
    else:
        B.append(u[i].split(','))

with open("output_4.txt",'w') as final:
    store= Multiply_matrix(A,B)
    final.write(str(store))