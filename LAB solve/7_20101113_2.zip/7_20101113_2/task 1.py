def bubbleSort(listy):
    for i in range(len(listy)-1):
        checker = False
        for j in range(len(listy)-i-1):
            if int(listy[j]) > int(listy[j+1]):
                listy[j+1], listy[j] = listy[j], listy[j+1]
                checker= True
        if checker != True:
            break
    return listy
#
f=open('input_1.txt','r')
t=f.read()
u=t.split('\n')
arr=u[1].split(' ')
with open("output_1.txt",'w') as final:
    output=''
    x = bubbleSort(arr)
    for i in x:
        output+=i+' '
    final.write(output)

