def selectio_sort(l):
    for i in range(len(l)):
        mini = i

        for j in range(i + 1, len(l)):

            if int(l[j]) < int(l[mini]):
                mini = j

        l[i],l[mini] = l[mini],l[i]
    return l

f=open('input_2.txt','r')
t=f.read()
u=t.split('\n')
ar1=u[0].split(' ')
ar2=u[1].split(' ')
with open("output_2.txt",'w') as final:
    output=''
    x = selectio_sort(ar2)
    for i in range(int(ar1[1])):
        output+= x[i]+' '
    final.write(output)