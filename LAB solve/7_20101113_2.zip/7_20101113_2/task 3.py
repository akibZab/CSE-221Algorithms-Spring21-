def insertion_sort(B,A):
    for i in range(1, len(B)):
        temp_1 = int(B[i])
        temp_2 = int(A[i])
        j = i - 1
        while j >= 0 and temp_1 > int(B[j]):
            B[j + 1] = int(B[j])
            A[j + 1] = int(A[j])
            j = j - 1

        B[j + 1] = temp_1
        A[j + 1] = temp_2
    return A

f=open('input_3.txt','r')
t=f.read()
u=t.split('\n')
A=u[1].split(' ')
B=u[2].split(' ')

with open("output_3.txt",'w') as final:
    output=''
    x = insertion_sort(B,A)
    for i in x:
        output+=str(i)+' '
    final.write(output)
