def merge(List, l, mid, r):
    n1 = mid - l + 1
    n2 = r - mid
    A = [0] * (n1)
    B = [0] * (n2)

    for i in range(0, n1):
        A[i] = List[l + i]
    for j in range(0, n2):
        B[j] = List[mid + j + 1]

    i = 0
    j = 0
    k = l
    while i < n1 and j < n2:
        if A[i] <= B[j]:
            List[k] = A[i]
            i += 1
        else:
            List[k] = B[j]
            j += 1
        k += 1

    while i < n1 or j < n2:
        if i < n1:
            List[k] = A[i]
            i += 1
            k += 1
        else:
            List[k] = B[j]
            j += 1
            k += 1


def merge_sort(List, l, r):
    if l < r:
        mid = (l + r) // 2
        merge_sort(List, l, mid)
        merge_sort(List, mid + 1, r)
        merge(List, l, mid, r)


f=open('input_4.txt','r')
t=f.read()
u=t.split('\n')
arr=u[1].split(' ')
arr2=[]
for i in arr:
    arr2.append(int(i))
with open("output_4.txt",'w') as final:
    output=''
    merge_sort(arr2,0,int(u[0])-1)
    for i in arr2:
        output+= str(i)+' '
    final.write(output)