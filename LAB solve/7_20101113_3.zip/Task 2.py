class graph:
    def __init__(self,node):
        self.node=node
        self.dic={}
        for i in range(1,self.node+1):
            self.dic[i]=[]
    def add_edge(self,u,v):
        self.dic[u].append(v)


o=open('input_1.txt','r')
f=o.read()
f=f.split('\n')
lis=[]
for i in range(1,len(f)):
    lis.append(f[i].split(' '))

node=int(f[0])
g=graph(node)
for i in lis:
    for j in range(1,len(i)):
        g.add_edge(int(i[0]),int(i[j]))
graf=g.dic

#============ Task 2 ===================================
ans=''
def bfs(city,graf,node,done):
    global ans
    city.append(node)
    gym.append(node)
    while gym:
        badge=gym.pop(0)
        ans+=str(badge)+' '
        if badge==done:
            return
        for i in graf[badge]:
            if i not in city:
                city.append(i)
                gym.append(i)

city=[]
gym=[]
bfs(city,graf,1,12)

with open('output_2.txt','w') as final:
        final.write(ans)