class graph:
    def __init__(self,node):
        self.node=node
        self.dic={}
        for i in range(1,self.node+1):
            self.dic[i]=[]
    def add_edge(self,u,v):
        self.dic[u].append(v)


o=open('input_1.txt','r')
f=o.read()
f=f.split('\n')
lis=[]
for i in range(1,len(f)):
    lis.append(f[i].split(' '))

node=int(f[0])
g=graph(node)
for i in lis:
    for j in range(1,len(i)):
        g.add_edge(int(i[0]),int(i[j]))
graf=g.dic

#============ Task 3 ======================

def dfs_visited(graf,n):
    for i in graf[n]:
        if i not in visited:
            visited.append(i)
            dfs_visited(graf,i)
def D_F_S(graf,done):
    for n in [*graf]:
        if n not in visited:
            visited.append(n)
            dfs_visited(graf,n)

visited=[]
done=12
D_F_S(graf,done)

with open('output_3.txt', 'w') as final:
    for i in visited:
        if i!=12:
            final.write(str(i)+' ')
        else:
            final.write(str(i))
            break
# print(visited)