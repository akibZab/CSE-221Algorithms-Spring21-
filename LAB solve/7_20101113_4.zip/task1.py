import heapq
def dijkstra(adjl,sauce):
    dists=[0]*len(adjl)
    visited=[0]*len(adjl)
    pred=[0]*len(adjl)
    pq=[]
    heapq.heapify(pq)
    for i in range(1,len(adjl)):
        if i!=sauce:
            dists[i]=1000
            pred[i]=0
    heapq.heappush(pq,(0,sauce))
    while len(pq)>0:
        u,v=heapq.heappop(pq)
        if visited[v]==1:
            continue
        visited[v]=1
        for j in adjl[v]:
            alt= u + j[1]
            if alt < dists[j[0]]:
                dists[j[0]]=alt
                pred[j[0]]=v
                heapq.heappush(pq,(dists[j[0]],j[0]))
    return dists[len(adjl)-1]


o=open('input2.txt','r')
answer=''
f=o.readline()
for i in range(int(f)):
    adjl = {}
    l=o.readline().split(' ')
    m=int(l[0])
    n=int(l[1])
    for i in range(m+1):
        adjl[i]=[]
    for i in range(n):
        k=o.readline().split(' ')
        x=int(k[0])
        y = int(k[1])
        z = int(k[2])
        adjl[x].append([y,z])

    out=dijkstra(adjl,1)
    answer+=str(out)+'\n'

with open('output 1.txt', 'w') as final:
    final.write(answer)




