import heapq
def Network(graph,sauce):
    visited=[0]*len(graph)
    disti=[0]*len(graph)
    pred = [0] * len(adjl)
    pq=[]
    heapq.heapify(pq)
    for i in range(1,len(graph)):
        if i!=sauce:
            disti[i] = -1000
            pred[i] = 0
    heapq.heappush(pq, (-1000,sauce))

    while len(pq) > 0:
        u, v = heapq.heappop(pq)
        if visited[v]==1:
            continue
        visited[v]=1
        for j in adjl[v]:
            alt = (min(-u, -j[1]))
            if alt > disti[j[0]]:
                disti[j[0]]=alt
                pred[j[0]]=v
                heapq.heappush(pq,(-disti[j[0]],j[0]))
    return disti



o=open('input3.txt','r')
answer=''
ans=''
f=o.readline()
for i in range(int(f)):
    adjl = {}
    l=o.readline().split(' ')
    m=int(l[0])
    n=int(l[1])

    for i in range(m+1):
        adjl[i]=[]
    for i in range(n):
        k=o.readline().split(' ')
        x=int(k[0])
        y = int(k[1])
        z = int(k[2])
        adjl[x].append([y,-z])

    srs=o.readline()
    sauce=int(srs)
    out=Network(adjl,sauce)
    for i in range(1,m+1):
        if out[i]== -1000:
            out[i]=-1
#=========== output ===========================
        answer+=str(out[i])+' '
    ans+=answer+'\n'
    answer=''
      # print(out[i],end=' ')
    #print()
with open('output 3.txt', 'w') as final:
    final.write(ans)