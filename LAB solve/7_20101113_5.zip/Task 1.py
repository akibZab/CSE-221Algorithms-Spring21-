def task1(dict):
    count=0
    f=0
    sample={}
    for i in dict:
        if count==0:
            f=i
            count+=1
            sample[i]=dict[i]
        else:
            for j in dict[i]:
                if j>=f:
                    count+=1
                    f=i
                    if i not in sample.keys():
                        sample[i]=[j]
                    else:
                        sample[i] += [j]
    return count,sample


k=open('input1.txt','r')
dic={}
dict={}
first=k.readline()
for i in range(int(first)):
    line=k.readline()
    line=line.split()

    if int(line[1]) not in dic.keys():
        dic[int(line[1])] = [int(line[0])]
    else:
        dic[int(line[1])] += [int(line[0])]
for i in sorted(dic):
    dict[i]=dic[i]
x=task1(dict)
with open('output1.txt','w') as final:
    final.write(str(x[0])+'\n')
    for i, y in x[1].items():
        for j in range(len(y)):
            final.write(str(y[j])+' '+str(i)+'\n')


