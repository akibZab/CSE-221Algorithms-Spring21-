def task2(dict, person):
    new={}
    for i in range(person):
        new[i] = []
    for i in dict:
        for j in dict[i]:
            for k in new:
                if len(new[k])==0 or j>=new[k][-1]:
                    new[k].append(i)
                    break

    return new


k = open('input2.txt', 'r')
dic = {}
dict = {}
first = k.readline().split()
for i in range(int(first[0])):
    line = k.readline()
    line = line.split()

    if int(line[1]) not in dic.keys():
        dic[int(line[1])] = [int(line[0])]
    else:
        dic[int(line[1])] += [int(line[0])]
for i in sorted(dic):
    dict[i] = dic[i]

new = {}
for i in range(int(first[1])):
    new[i] = []

x=task2(dict,int(first[1]))
ans=0
with open('output2.txt','w') as final:
    for i in x:
        ans+=len(x[i])
    final.write(str(ans))