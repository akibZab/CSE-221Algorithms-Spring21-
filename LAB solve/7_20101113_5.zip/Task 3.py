def task3(f,times,names):
    jack=0
    jill=0
    all=''
    sta=[]
    for i in names:
        if i=='J':
            all+=times[0]
            jack+=int(times[0])
            sta.append(int(times[0]))
            times=times[1:len(times)]
        else:
            x=sta.pop()
            all+=str(x)
            jill+=x
    return str(jack)+' '+str(jill)+' '+str(all)


so=open('input3.txt','r')
f=so.readline()
times=so.readline().split()
times.sort()
names=so.readline()

ans=task3(f,times,names)
ans=ans.split(' ')
with open('output3.txt','w') as final:

    final.write(ans[2]+'\n')
    final.write('Jack will work for '+ans[0]+' hours'+'\n')
    final.write('Jill will work for ' + ans[1] + ' hours')





