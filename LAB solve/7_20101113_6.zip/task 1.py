def task_1(m,n):
    x=len(m)
    y=len(n)
    pubg={'Y':'Yasnaya','P':'Pochinki','S':'School','R':'Rozhok','F':'Farm','M':'Mylta','H':'Shelter','I':'Prison'}

    # h=[]
    # for i in range(x+1):
    #     h.append([None]*(y+1))
    # print(h)
    h=[[None]*(y+1) for i in range(x+1)]
    for i in range(x+1):
        for j in range(y+1):
            if i==0 or j==0:
                h[i][j]=0
            elif m[i-1]==n[j-1]:
                h[i][j]=h[i-1][j-1]+1
            else:
                h[i][j]= max(h[i-1][j],h[i][j-1])

    a=x
    s=y
    lis=[0]*(h[x][y])
    ind=(h[x][y])
    while a>0 and s>0:
        if m[a-1] == n[s-1]:
            lis[ind-1] = pubg[m[a-1]]
            a-=1
            s-=1
            ind-=1
        elif h[a-1][s] > h[a][s-1]:
            a-=1
        else:
            s-=1
    return h[x][y], lis

#================= input & output =====================
f=open('input 1.txt','r')
no=int(f.readline())
m=f.readline()
m=m[0:len(m)-1]
n=f.readline()
ans=task_1(m,n)
output1=int(ans[0])/len(m)*100
output2=ans[1]
with open('output 1.txt','w') as final:
    out = ''
    for i in output2:
        out = out + i + ' '
    final.write(out+'\n')
    final.write('Correctness of prediction: '+str(output1)+'%')
