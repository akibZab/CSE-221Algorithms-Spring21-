def task_2(m,n):
    x=len(m)
    y=len(n)


    h=[[None]*(y+1) for i in range(x+1)]
    for i in range(x+1):
        for j in range(y+1):
            if i==0 or j==0:
                h[i][j]=0
            elif m[i-1]==n[j-1]:
                h[i][j]=h[i-1][j-1]+1
            else:
                h[i][j]= max(h[i-1][j],h[i][j-1])

    a=x
    s=y
    lis=[0]*(h[x][y])
    ind=(h[x][y])
    while a>0 and s>0:
        if m[a-1] == n[s-1]:
            lis[ind-1] = m[a-1]
            a-=1
            s-=1
            ind-=1
        elif h[a-1][s] > h[a][s-1]:
            a-=1
        else:
            s-=1
    return lis


f=open('input 2.txt','r')
m=f.read()
V=m.split('\n')
m=V[0]
n=V[1]
o=V[2]
ans= task_2(m,n)
ans=''.join(ans)
ans2= task_2(ans,o)
ans2=''.join(ans2)
with open('output 2.txt','w') as final:
    final.write(str(len(ans2)))